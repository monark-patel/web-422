/*********************************************************************************
*  WEB422 – Assignment 2
*  I declare that this assignment is my own work in accordance with Seneca Academic Policy.  
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: _Monark Patel_ Student ID: _135845162_ Date: _09-28-2018_
*
*
********************************************************************************/ 

$(function () {

  let employeesModel = [];

  initializeEmployeesModel();
  ////////////Initiate////////
  function initializeEmployeesModel() {


    $.ajax({

      url: "https://web422a1.herokuapp.com/employees", // This only works if the Teams API is running locally - change this url to your Heroku API (/employees) to use your API on Heroku
      type: "GET",

      contentType: "application/json"

    })

      .done(function (employees) {
        employeesModel = employees;
        refreshEmployeeRows(employees);

      })
      .fail(function (err) {

        showGenericModal('Error', 'Unable to get employees');
      });

  }

  ////////MODAL////////////////
  function showGenericModal(title, message) {         //called Check


    $(".modal-title").text(title);
    $(".modal-body").text(message);

    $("#genericModal").modal({ show: 'false' });


  }

  //Refreshing////////////
  function refreshEmployeeRows(employees) {

    let template1 = _.template('<% _.forEach(employees, function(employee) { %>' +

      ' <div class="row body-row" data-id="<%- employee._id %>">' +
      '<div class="col-xs-4 body-column"><%- employee.FirstName %> </div>' +
      '<div class="col-xs-4 body-column"><%- employee.LastName %> </div>' +
      '<div class="col-xs-4 body-column"><%- employee.Position.PositionName %> </div>'
      + '</div>' +
      '<% }); %>');
    let template1Result = template1({ 'employees': employees });

    //body.empty();
    let target = $("#employees-table");
    target.empty();

    target.append(template1Result);
  }
  //////////Filtering///

  function getFilteredEmployeesModel(filterString) {
    var re = new RegExp(filterString.toUpperCase());
    let asortedEmployees = _.filter(employeesModel, function (employee) {
      var empFName = employee.FirstName.toUpperCase();
      var empLName = employee.LastName.toUpperCase();
      var empPosition = employee.Position.PositionName.toUpperCase();



      if ((empFName.search(re) > -1)
        || (empLName.search(re) > -1)
        || (empPosition.search(re) > -1)) {

        return true;
      }
      else
        return false;
    });

    return asortedEmployees;

  }
  function getEmployeeModelById(id) {
    let findEMP = _.find(employeesModel, function (employee) {
      if (employee._id == id) {

        return _.cloneDeep(employee);
      }
      else null
    });


    return findEMP;
  }

  /////////////////////////////////////////////////////////////////


  initializeEmployeesModel();
  $("#employee-search").on("keyup", function () {
    let toSearch = $("#employee-search").val();
    let result = getFilteredEmployeesModel(toSearch);

    refreshEmployeeRows(result);
  });



  $(".bootstrap-header-table").on("click", ".body-row", function () {

    let id_ = $(this).attr("data-id");
    let getEmp = getEmployeeModelById(id_);
    let EmpDate = moment(getEmp.HireDate);

    getEmp.HireDate = EmpDate.format("LL");
    let frame = _.template(
      '<strong>Address:</strong> <%- employee.AddressStreet %> <%- employee.AddressCity %> <%- employee.AddressState %> <%- employee.AddressZip %><br>' +
      '<strong>Phone Number:</strong> <%-employee.PhoneNum %> Ext: <%-employee.Extension %><br>' +
      '<strong>Hire Date:</strong> <%- employee.HireDate %>');

    let render = frame({ 'employee': getEmp });

    $("#genericModal").modal();
    $(".modal-title").empty();
    $(".modal-body").empty();

    $(".modal-title").text(getEmp.FirstName + " " + getEmp.LastName);
    $(".modal-body").html(render);
  });
});