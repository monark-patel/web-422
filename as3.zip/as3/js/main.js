
/*********************************************************************************
*  WEB422 – Assignment 03
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part of this
*  assignment has been copied manually or electronically from any other source (including web sites) or 
*  distributed to other students.
* 
*  Name: _Monark Patel_ Student ID: _135845162_ Date: _10-12-2018_
*
********************************************************************************/ 


var viewModel = {
  teams: ko.observableArray([]),
  employees: ko.observableArray([]),
  projects: ko.observableArray([])
};

function initializeTeams() {
  console.log("Initializing team data");
  return new Promise(function (resolve, reject) {

    $.ajax({

      url: "https://web422a1.herokuapp.com/teams-raw", // This only works if the Teams API is running locally - change this url to your Heroku API (/employees) to use your API on Heroku
      type: "GET",

      contentType: "application/json"

    }).done(function (data) {
      viewModel.teams = ko.mapping.fromJS(data);
      console.log("Hurray TEams");
      console.log(viewModel.teams.length);
      resolve();
    })

      .fail(function () {
        showGenericModal("Error", "Error loading Team Data");
        console.log("No !! Teams");
        reject("Unable to read file!");
      });
  }
  )
}

function initializeEmployees() {

  return new Promise(function (resolve, reject) {

    $.ajax({

      url: "https://web422a1.herokuapp.com/employees", // This only works if the Teams API is running locally - change this url to your Heroku API (/employees) to use your API on Heroku
      type: "GET",

      contentType: "application/json"

    }).done(function (data) {
      viewModel.employees = ko.mapping.fromJS(data);
      console.log("Hurray employees")
      resolve();
    })

      .fail(function () {
        showGenericModal("Error", "Error loading Employee Data");
        console.log("No !! employees");
        reject("Unable to read file!");
      });
  }
  )
}

function initializeProjects() {

  return new Promise(function (resolve, reject) {

    $.ajax({

      url: "https://web422a1.herokuapp.com/projects", // This only works if the Teams API is running locally - change this url to your Heroku API (/employees) to use your API on Heroku
      type: "GET",

      contentType: "application/json"

    }).done(function (data) {
      viewModel.projects = ko.mapping.fromJS(data);
      console.log("Hurray projects")
      resolve();
    })

      .fail(function () {
        showGenericModal("Error", "Error loading Project Data");
        console.log("No !! Projects");
        reject("Unable to read file!");
      });
  }
  )
}

initializeTeams()
  .then(initializeEmployees)
  .then(initializeProjects)
  .then(function () {
    console.log("Allocated arrays");

  })
  .catch(function () {
    // catch any errors here

    console.log("Allocation Fail in Promise chain");
  });
function showGenericModal(title, message) {         //called Check


  $(".modal-title").text(title);
  $(".modal-body").text(message);

  $("#genericModal").modal({ show: 'false' });


}

function saveTeam() {
  var currentTeam = this;
  var obj = {
    "Projects": currentTeam.Projects(),
    "Employees": currentTeam.Employees(),
    "TeamLead": currentTeam.TeamLead()
  };
  $.ajax({

    url: "https://web422a1.herokuapp.com/team/" + currentTeam._id(), // This only works if the Teams API is running locally - change this url to your Heroku API (/employees) to use your API on Heroku
    type: "PUT",
    data: JSON.stringify(obj),

    contentType: "application/json"

  }).done(function (data) {
    showGenericModal("Success","Data in "+currentTeam.TeamName()+" Updated");
  })
    .fail(function (data) {
      showGenericModal("Error");
    })
}
///////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

$(function () {
  initializeTeams()
    .then(initializeEmployees)
    .then(initializeProjects)
    .then(function () {
      console.log("Allocated arrays");
      ko.applyBindings(viewModel);
      $(".multiple").multipleSelect({ filter: true });
      $(".single").multipleSelect({ single: true, filter: true });

    })
    .catch(function (message) {
      // catch any errors here
      showGenericModal("Error", message);
      console.log("Allocation Fail in Promise chain");
    });



});
////////////////

