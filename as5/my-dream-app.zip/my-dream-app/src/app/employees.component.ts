import { Component, OnInit } from '@angular/core';
import { Employee } from './data/employee';
import {EmployeeServiceService} from './data/employee-service.service';
import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
   employees : Employee[] ;
  getEmployeesSub: any;
  loadingError : boolean = false;

  constructor(private EmployeesService: EmployeeServiceService) { }

  ngOnInit() {
    this.getEmployeesSub = this.EmployeesService.getEmployees().subscribe( data => {
      this.employees = data;
      }, () =>{
      this.loadingError = true;
    });  
  }
  ngOnDestroy() {
    if(this.getEmployeesSub){this.getEmployeesSub.unsubscribe();}
  }
}
